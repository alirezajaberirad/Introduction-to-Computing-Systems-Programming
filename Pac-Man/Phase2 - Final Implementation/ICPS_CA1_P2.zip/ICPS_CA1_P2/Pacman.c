#include "Pacman.h"


void initScreen()
{
	COORD coord;
	HANDLE stdHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleDisplayMode(stdHandle, CONSOLE_FULLSCREEN_MODE, &coord);

}

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}


int waitAndGetDirection(int waitTime, int *direction)
{
	DWORD start_time, check_time;

	start_time = GetTickCount();
	check_time = start_time + waitTime; //GetTickTime returns time in miliseconds
	char ch = 0;
	char hit = 0;

	while (check_time>GetTickCount())
	{
		if (_kbhit())
		{
			hit = 1;
			ch = _getch();
			if (ch == 0)
				ch = _getch();
			break;
		}
	}

	switch (ch)
	{
	case 'w':
		ch = 'u';
		break;
	case 'z':
		ch = 'd';
		break;
	case 'a':
		ch = 'l';
		break;
	case 's':
		ch = 'r';
		break;
	default:
		break;
	}

	if (ch != *direction && (ch == 'u' || ch == 'd' || ch == 'l' || ch == 'r'))
	{
		*direction = ch;
		return 1;
	}
	else
		return 0;

}


